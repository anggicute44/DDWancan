package id.app.ddwancan.view.screen.detail

