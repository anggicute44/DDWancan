package id.app.ddwancan.navigation


enum class NavRoutes {
    HOME, FAVORITE, SEARCH, PROFILE
}
