package id.app.ddwancan.viewmodel

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {
}