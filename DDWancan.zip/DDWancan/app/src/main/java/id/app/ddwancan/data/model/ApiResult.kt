package id.app.ddwancan.data.model

